const mongoose = require('mongoose');

const BudgetSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    categoryId: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
    monthYear: { type: String, required: true },
    amount: { type: Number, required: true, min: 0 }
}, { timestamps: true });

BudgetSchema.index({ userId: 1, categoryId: 1, monthYear: 1 }, { unique: true });

module.exports = mongoose.model('Budget', BudgetSchema);